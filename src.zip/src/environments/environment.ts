export const environment = {
  backendUrl: 'http://3.84.132.167:8080'
};
