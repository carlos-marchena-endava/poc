export const environment = {
  //backendUrl: 'http://localhost:8080'
  backendUrl: 'http://3.84.132.167:8080'
};
