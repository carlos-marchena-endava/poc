import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyInitializationComponent } from './policy-initialization.component';

describe('PolicyInitializationComponent', () => {
  let component: PolicyInitializationComponent;
  let fixture: ComponentFixture<PolicyInitializationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyInitializationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PolicyInitializationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
