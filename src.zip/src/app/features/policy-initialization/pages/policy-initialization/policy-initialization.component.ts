import {Component, inject, OnInit} from '@angular/core';
import {MatGridListModule} from "@angular/material/grid-list";
import {PolicyInformationComponent} from "../../components/policy-information/policy-information.component";
import {
  PolicyInitializationFormComponent
} from "../../components/policy-initialization-form/policy-initialization-form.component";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {IPolicy} from "../../../../core/models/policy.model";
import {IPolicyInitialization} from "../../../../core/models/policy-initialization.model";
import {BackendApiService} from "../../../../core/services/backend-api.service";
import {HttpErrorResponse} from "@angular/common/http";
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-policy-initialization',
  standalone: true,
  imports: [MatGridListModule, PolicyInformationComponent, PolicyInitializationFormComponent, MatProgressSpinnerModule],
  templateUrl: './policy-initialization.component.html',
  styleUrl: './policy-initialization.component.css'
})
export class PolicyInitializationComponent implements OnInit {

  policy: IPolicy = {};

  policyAlreadyExists: boolean = false;
  isRequestSuccessful: boolean = false;
  isLoading: boolean = false;

  resultTitle: string = '';
  resultMessage: string = '';

  private _activatedRoute: ActivatedRoute = inject(ActivatedRoute);
  private _router: Router = inject(Router);
  private _backendApi: BackendApiService = inject(BackendApiService);

  ngOnInit(): void {
    this._activatedRoute.queryParams.subscribe({
        next: params => {
          this.initializePolicy(params);
          this.validatePolicyInitialization();
        },
        error: err => {
          console.error(err);
          this._router.navigate(['/']);
        }
      }
    )

    this._backendApi.checkIfDocumentForThePolicyAlreadyExist().subscribe({
      next: result => {
        console.log(result);
        if (result) {
          this.resultTitle = 'A Document for this policy already exist in the E-Init database.';
          this.resultMessage = 'Close the browser window and completes a new business transaction.';
          this.isRequestSuccessful = true;
          this.policyAlreadyExists = true;
        }
      },
      error: err => {
        console.error(err);
        alert('An Unexpected error has occurred.');
        this._router.navigate(['/']);
      }
    })
  }

  processResult(formData: IPolicyInitialization): void {
    console.log(formData);
    this.isLoading = true;
    this._backendApi.savePolicyInitialization(this.policy, formData).subscribe(
      {
        next: params => {
          this.resultTitle = 'Success';
          this.resultMessage = 'The Policy Initialization was successful.\n' +
            'Please close the browser and complete the new business transaction.';
          this.isRequestSuccessful = true;
          this.isLoading = false;
        },
        error: (err: HttpErrorResponse) => {
          if (err.status === 500) {
            this.resultTitle = 'An Error occurred while processing results';
            this.resultMessage = err.message + '\n' +
              'Return to Collaborative Edge or simply close the browser window.';
            this.isRequestSuccessful = true;
          } else {
            alert('An Error occurred while processing results. \nDetail: ' + err.error.message);
          }
          this.isLoading = false;
        }
      }
    )
  }

  private initializePolicy(params: Params): void {
    this.policy.openForm = params['OpenForm'];
    this.policy.pn = params['PN'];
    this.policy.ag = params['AG'];
    this.policy.bs = params['BS'];
    this.policy.tf = this.parseDate(params['TF']);
    this.policy.i1 = params['I1'];
    this.policy.i2 = params['I2'];
    this.policy.ms = params['MS'];
    this.policy.mc = params['MC'];
    this.policy.mt = params['MT'];
    this.policy.mz = params['MZ'];
    this.policy.rs = params['RS'];
    this.policy.rc = params['RC'];
    this.policy.rt = params['RT'];
    this.policy.rz = params['RZ'];
    this.policy.gd = params['GD'] ? params['GD'] : 'No group';
    this.policy.am = params['AM'];
    this.policy.mi = params['MI'];
    this.policy.m3 = params['M3'];
    this.policy.oi = params['OI'];
    this.policy.pp = params['PP'];
    this.policy.pd = params['PD'];
    this.policy.pt = params['PT'];
    this.policy.cn = params['CN'];
    this.policy.sc = params['SC'];
    console.log(this.policy)
  }

  private parseDate(rawDate: string): string {
    let regExp = new RegExp('^(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])\\d{4}$');
    if (regExp.test(rawDate)) {
      let month = rawDate.slice(0, 2);
      let day = rawDate.slice(2, 4);
      let year = rawDate.slice(4, 8);
      return formatDate(new Date(Number(year), Number(month) - 1, Number(day)), 'yyyy-MM-dd', 'en-US');
    } else {
      console.log("Invalid Date");
      return '';
    }
  }

  private validatePolicyInitialization(): void {
    //?OpenForm&PN=DBBZM7&AG=0QU&BS=D&TF=09132021&I1=Annalisa+Dantona&I2=&MS=&MC=&MT=&MZ=&RS=236+Nahant+Rd&RC=Nahant&RT=MA&RZ=019081241&GD=&AM=&MI=N&M3=N&OI=MA0093&PP=3088.00&PD=&PT=MMC&CN=01&SC=AP
    if (!this.policy.pn ||
      !this.policy.ag ||
      !this.policy.bs ||
      !this.policy.tf ||
      !this.policy.i1 ||
      !this.policy.rs ||
      !this.policy.rc ||
      !this.policy.rt ||
      !this.policy.rz ||
      (this.policy.gd === undefined) ||
      !this.policy.pt ||
      !this.policy.cn ||
      !this.policy.sc) {
      alert("Invalid request")
      this._router.navigate(['/']);
    }
  }
}
