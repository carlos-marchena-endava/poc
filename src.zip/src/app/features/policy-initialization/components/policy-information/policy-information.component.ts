import {Component, Input, OnInit} from '@angular/core';
import {IPolicy} from "../../../../core/models/policy.model";
import {DatePipe} from "@angular/common";
import {ZipCodePipe} from "../../../../core/pipes/zip-code.pipe";

@Component({
  selector: 'app-policy-information',
  standalone: true,
  imports: [
    DatePipe,
    ZipCodePipe
  ],
  templateUrl: './policy-information.component.html',
  styleUrl: './policy-information.component.css'
})
export class PolicyInformationComponent implements OnInit {

  @Input({required: true})
  policy: IPolicy = {};

  ngOnInit(): void {
  }


}
