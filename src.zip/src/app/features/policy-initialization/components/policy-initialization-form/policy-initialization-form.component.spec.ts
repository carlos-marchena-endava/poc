import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyInitializationFormComponent } from './policy-initialization-form.component';

describe('PolicyInitializationFormComponent', () => {
  let component: PolicyInitializationFormComponent;
  let fixture: ComponentFixture<PolicyInitializationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyInitializationFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PolicyInitializationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
