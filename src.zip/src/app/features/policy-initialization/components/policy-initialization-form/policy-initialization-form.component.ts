import {Component, EventEmitter, inject, OnInit, Output} from '@angular/core';
import {MatFormFieldModule} from "@angular/material/form-field";
import {CommonModule} from "@angular/common";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {MatRadioModule} from "@angular/material/radio";
import {MatSelectModule} from "@angular/material/select";
import {BackendApiService} from "../../../../core/services/backend-api.service";
import {IFinanceCompany} from "../../../../core/models/finance-company.model";
import {MatInputModule} from "@angular/material/input";
import {MatButtonModule} from "@angular/material/button";
import {MatDividerModule} from "@angular/material/divider";
import {PaymentTypeEnum} from "../../../../core/models/payment-type.model";
import {PaymentPlanEnum} from "../../../../core/models/payment-plan.model";
import {PaymentMethodEnum} from "../../../../core/models/payment-method.model";
import {BusinessTypeEnum} from "../../../../core/models/business-type.model";
import {MatCheckboxModule} from "@angular/material/checkbox";
import {IPolicyInitialization} from "../../../../core/models/policy-initialization.model";
import {Router} from "@angular/router";

@Component({
  selector: 'app-policy-initialization-form',
  standalone: true,
  imports: [ReactiveFormsModule,
    CommonModule,
    MatFormFieldModule,
    MatRadioModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatDividerModule,
    MatCheckboxModule],
  templateUrl: './policy-initialization-form.component.html',
  styleUrl: './policy-initialization-form.component.css'
})
export class PolicyInitializationFormComponent implements OnInit {

  @Output() processEvent: EventEmitter<IPolicyInitialization> = new EventEmitter();

  generalForm: FormGroup;
  financeCompanies: IFinanceCompany[] = [];
  businessTypes: string[] = Object.keys(BusinessTypeEnum);
  paymentTypes: string[] = Object.keys(PaymentTypeEnum);
  paymentPlans: string[] = [];
  paymentMethods: string[] = [];

  showFinanceCompanyField: boolean = false;
  showActiveCICPolicyField: boolean = false;
  showPaymentSectionFields: boolean = false;
  showMakePaymentButton: boolean = false;
  showPaymentByCheckConfirmedField: boolean = false;

  financeCompanyErrorMessage: string = 'You must select a Finance Company';
  activeCICPolicyErrorMessage: string = 'You must enter a value';
  paymentAmountErrorMessage: string = 'You must enter a value';
  isPaymentByCheckConfirmedErrorMessage: string = 'This field must be checked';

  private _formBuilder: FormBuilder = inject(FormBuilder);
  private _router: Router = inject(Router);
  private _backendApi: BackendApiService = inject(BackendApiService);

  constructor() {
    this.generalForm = this._formBuilder.group({
      isPolicyFinanced: ['', [Validators.required]],
      financeCompany: ['', []],
      typeOfBusiness: ['', [Validators.required]],
      activeCICPolicy: ['', []],
      paymentType: ['', [Validators.required]],
      paymentPlan: ['', [Validators.required]],
      paymentAmount: ['', [Validators.required]],
      paymentMethod: ['', [Validators.required]],
      memo: ['', [Validators.required, Validators.maxLength(200)]],
      isPaymentByCheckConfirmed: ['', []],
    });
  }

  ngOnInit(): void {
    this.whenIsPolicyFinancedControlChange();
    this.whenTypeOfBusinessControlChange();
    this.whenPaymentTypeControlChange();
    this.setUpInitialValues();
  }

  getBusinessTypeValue(businessType: string) {
    return BusinessTypeEnum[businessType as keyof typeof BusinessTypeEnum];
  }

  getPaymentTypeValue(paymentType: string) {
    return PaymentTypeEnum[paymentType as keyof typeof PaymentTypeEnum];
  }

  getPaymentPlanValue(paymentPlan: string) {
    return PaymentPlanEnum[paymentPlan as keyof typeof PaymentPlanEnum];
  }

  getPaymentMethodValue(paymentMethod: string) {
    return PaymentMethodEnum[paymentMethod as keyof typeof PaymentMethodEnum];
  }

  continueWithPaymentSection() {
    //TODO: Should i check previous fields
    let paymentTypeValue = this.generalForm.controls["paymentType"].value;
    if (paymentTypeValue === 'PAID_AT_AGENCY' as keyof typeof PaymentTypeEnum || paymentTypeValue === 'PAY_BY_CHECK' as keyof typeof PaymentTypeEnum) {
      this.showPaymentSectionFields = true;
    }
  }

  updateMemoErrorMessage(): string {
    let memo = this.generalForm.controls["memo"];
    if (memo.hasError('required')) {
      return 'You must enter a value';
    } else if (memo.hasError('maxlength')) {
      return 'Maximum length is 200 characters';
    } else {
      return '';
    }
  }

  makePayment(): void {
    this.showPaymentByCheckConfirmedField = true;
    window.open("https://www.cie.paybill.com/V2/PaymentWorkflow/EnterPaymentInformation", "_blank");
  }

  process(): void {
    if (this.generalForm.valid) {
      const values = this.generalForm.value;
      let result: IPolicyInitialization = {
        isPolicyFinanced: values.isPolicyFinanced,
        financeCompanyId: values.financeCompany,
        typeOfBusiness: values.typeOfBusiness,
        activeCICPolicy: values.activeCICPolicy,
        paymentType: values.paymentType,
        paymentPlan: values.paymentPlan,
        paymentAmount: values.paymentAmount,
        paymentMethod: values.paymentMethod,
        memo: values.memo,
        isPaymentByCheckConfirmed: values.isPaymentByCheckConfirmed
      };
      this.processEvent.emit(result);
    }
  }

  exitNoSave(): void {
    this._router.navigate(['/']);
  }

  private whenIsPolicyFinancedControlChange() {
    this.generalForm.controls["isPolicyFinanced"].valueChanges.subscribe((isPolicyFinanced: boolean) => {
      if (isPolicyFinanced) {

        this.generalForm.controls['financeCompany'].addValidators([Validators.required]);
        this.generalForm.controls['financeCompany'].updateValueAndValidity();
        this.showFinanceCompanyField = true;

        this.getAllFinanceCompanies();

        this.updatePaymentPlan('FULL_PAY' as keyof typeof PaymentPlanEnum);

      } else {

        this.generalForm.controls['financeCompany'].clearValidators();
        this.generalForm.controls['financeCompany'].updateValueAndValidity();
        this.showFinanceCompanyField = false;

        this.financeCompanies = [];

        this.updatePaymentPlan('ELEVEN_PAY' as keyof typeof PaymentPlanEnum);
      }
    })
  }

  private getAllFinanceCompanies() {
    this._backendApi.getAllFinanceCompanies().subscribe({
      next: result => this.financeCompanies = result,
      error: err => console.log(err)
    });
  }

  private updatePaymentPlan(paymentPlan: string): void {
    this.paymentPlans = [];
    this.paymentPlans.push(paymentPlan)
    this.generalForm.controls['paymentPlan'].setValue(this.paymentPlans[0]);
  }

  private whenTypeOfBusinessControlChange() {
    this.generalForm.controls['typeOfBusiness'].valueChanges.subscribe((typeOfBusiness) => {
      if (typeOfBusiness === ('REPLACING_ACTIVE_CIC_POLICY' as keyof typeof BusinessTypeEnum)) {

        this.generalForm.controls['activeCICPolicy'].addValidators([Validators.required]);
        this.generalForm.controls['activeCICPolicy'].updateValueAndValidity();
        this.showActiveCICPolicyField = true;
      } else {

        this.generalForm.controls['activeCICPolicy'].clearValidators();
        this.generalForm.controls['activeCICPolicy'].updateValueAndValidity();
        this.showActiveCICPolicyField = false;
      }
    })
  }

  private whenPaymentTypeControlChange() {
    this.generalForm.controls['paymentType'].valueChanges.subscribe((paymentType) => {
      this.showPaymentSectionFields = false // Current functionality don't do this;
      if (paymentType === 'PAID_AT_AGENCY' as keyof typeof PaymentTypeEnum) {

        this.generalForm.controls['isPaymentByCheckConfirmed'].clearValidators();
        this.generalForm.controls['isPaymentByCheckConfirmed'].updateValueAndValidity();

        this.updatePaymentMethods('NONE' as keyof typeof PaymentMethodEnum);
        this.showMakePaymentButton = false;
      } else if (paymentType === 'PAY_BY_CHECK' as keyof typeof PaymentTypeEnum) {

        this.generalForm.controls['isPaymentByCheckConfirmed'].addValidators([Validators.requiredTrue]);
        this.generalForm.controls['isPaymentByCheckConfirmed'].updateValueAndValidity();

        this.updatePaymentMethods('PAY_BY_CHECK' as keyof typeof PaymentMethodEnum);
        this.showMakePaymentButton = true;
      } else {

        this.generalForm.controls['isPaymentByCheckConfirmed'].clearValidators();
        this.generalForm.controls['isPaymentByCheckConfirmed'].updateValueAndValidity();

        this.showMakePaymentButton = false;
        this.paymentMethods = [];
      }
    })
  }

  private updatePaymentMethods(paymentMethods: string): void {
    this.paymentMethods = [];
    this.paymentMethods.push(paymentMethods)
    this.generalForm.controls['paymentMethod'].setValue(this.paymentMethods[0]);
  }

  private setUpInitialValues(): void {
    this.generalForm.controls["isPolicyFinanced"].setValue(false);
    this.generalForm.controls["typeOfBusiness"].setValue('NEW_BUSINESS' as keyof typeof BusinessTypeEnum);
    this.generalForm.controls["paymentType"].setValue('NONE' as keyof typeof PaymentTypeEnum);
  }
}
