import {Routes} from '@angular/router';
import {
  PolicyInitializationComponent
} from "./features/policy-initialization/pages/policy-initialization/policy-initialization.component";
import {PageNotFoundComponent} from "./shared/pages/page-not-found/page-not-found.component";


export const routes: Routes = [
  {path: 'EntryForm', component: PolicyInitializationComponent},
  {path: '**', component: PageNotFoundComponent}
];
