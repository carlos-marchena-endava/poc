import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {from, Observable} from "rxjs";
import {IFinanceCompany} from "../models/finance-company.model";
import {IPolicy} from "../models/policy.model";
import {IPolicyInitialization} from "../models/policy-initialization.model";
import {environment} from "../../../environments/environment";
import {IPolicyOut} from "../models/policy-out.model";
import {IPolicyIn} from "../models/policy-in.model";

@Injectable({
  providedIn: 'root'
})
export class BackendApiService {

  private apiUrl: string = environment.backendUrl;
  private _http: HttpClient = inject(HttpClient);

  constructor() {
  }

  getAllFinanceCompanies(): Observable<IFinanceCompany[]> {
    return this._http.get<IFinanceCompany[]>(this.apiUrl + '/finance-companies');
  }

  savePolicyInitialization(policyInformation: IPolicy, formData: IPolicyInitialization): Observable<IPolicyOut> {
    let body: IPolicyIn = {
      policyNumber: policyInformation.pn as string,
      company: policyInformation.cn as string,
      policyType: policyInformation.pt as string,
      billingIndicator: policyInformation.bs as string,
      agent: policyInformation.ag as string,
      policyGroup: policyInformation.gd as string,
      effectiveDate: policyInformation.tf as string,
      insuredName1: policyInformation.i1 as string,
      insuredName2: policyInformation.i2,
      residenceStreet: policyInformation.rs as string,
      residenceCity: policyInformation.rc as string,
      residenceState: policyInformation.rt as string,
      residenceZipCode: policyInformation.rz as string,
      mailStreet: policyInformation.ms,
      mailCity: policyInformation.mc,
      mailState: policyInformation.mt,
      mailZipCode: policyInformation.mz,
      requestSource: policyInformation.sc as string,
      policyInitialization: {
        isPolicyBeingFinanced: formData.isPolicyFinanced,
        financeCompanyId: formData.financeCompanyId,
        typeOfBusiness: formData.typeOfBusiness,
        activeCICPolicyNumber: formData.activeCICPolicy,
        paymentType: formData.paymentType,
        paymentPlan: formData.paymentPlan,
        paymentAmount: formData.paymentAmount,
        paymentMethod: formData.paymentMethod,
        memo: formData.memo,
        isPaymentByCheckConfirmed: formData.isPaymentByCheckConfirmed
      }
    }
    return this._http.post<IPolicyOut>(this.apiUrl + '/policies', body);
  }

  checkIfDocumentForThePolicyAlreadyExist(): Observable<boolean> {
    return from([false]);
  }

}
