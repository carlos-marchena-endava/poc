import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'zipCode',
  standalone: true
})
export class ZipCodePipe implements PipeTransform {

  transform(value: string | undefined): string {
    return value ? value.slice(0, 5) + '-' + value.slice(5) : '';
  }

}
