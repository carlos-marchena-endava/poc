export interface IPolicyIn {
  policyNumber: string;
  company: string;
  policyType: string;
  billingIndicator: string;
  agent: string;
  policyGroup: string;
  effectiveDate: string;
  insuredName1: string;
  insuredName2?: string;
  residenceStreet: string;
  residenceCity: string;
  residenceState: string;
  residenceZipCode: string;
  mailStreet?: string;
  mailCity?: string;
  mailState?: string;
  mailZipCode?: string;
  requestSource: string;
  policyInitialization: IPolicyInitializationIn;
}

export interface IPolicyInitializationIn {
  isPolicyBeingFinanced: boolean;
  financeCompanyId?: string;
  typeOfBusiness: string;
  activeCICPolicyNumber?: string;
  paymentType: string;
  paymentPlan: string;
  paymentAmount: number;
  paymentMethod: string;
  memo: string;
  isPaymentByCheckConfirmed?: boolean;
}
