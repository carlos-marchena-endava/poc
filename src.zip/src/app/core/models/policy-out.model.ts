import {IFinanceCompany} from "./finance-company.model";

export interface IPolicyOut {
  id: string;
  policyNumber: string;
  company: string;
  policyType: string;
  billingIndicator: string;
  agent: string;
  policyGroup: string;
  effectiveDate: Date;
  insuredName1: string;
  insuredName2: string;
  residenceStreet: string;
  residenceCity: string;
  residenceState: string;
  residenceZipCode: string;
  mailStreet: string;
  mailCity: string;
  mailState: string;
  mailZipCode: string;
  requestSource: string;
  policyInitialization: IPolicyInitializationOut;
}

export interface IPolicyInitializationOut {
  id: string;
  isPolicyBeingFinanced: boolean;
  financeCompany: IFinanceCompany;
  typeOfBusiness: string;
  activeCICPolicyNumber: string;
  paymentType: string;
  paymentPlan: string;
  paymentAmount: number;
  paymentMethod: string;
  memo: string;
  isPaymentByCheckConfirmed: boolean;
}
