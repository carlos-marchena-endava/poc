export interface IFinanceCompany {
  id: string
  name: string
}
