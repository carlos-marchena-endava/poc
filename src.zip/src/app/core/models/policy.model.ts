export interface IPolicy {
  ag?: string;
  am?: string;
  bs?: string;
  cn?: string;
  gd?: string;
  i1?: string;
  i2?: string;
  m3?: string;
  mc?: string;
  mi?: string;
  ms?: string;
  mt?: string;
  mz?: string;
  oi?: string;
  openForm?: string;
  pd?: string;
  pn?: string;
  pp?: string;
  pt?: string;
  rc?: string;
  rs?: string;
  rt?: string;
  rz?: string;
  sc?: string;
  tf?: string;
}
