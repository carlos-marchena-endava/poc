export enum PaymentPlanEnum {
  ELEVEN_PAY = "11-Pay",
  FULL_PAY = "Full-Pay"
}
