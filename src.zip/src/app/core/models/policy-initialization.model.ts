import {BusinessTypeEnum} from "./business-type.model";
import {PaymentTypeEnum} from "./payment-type.model";
import {PaymentPlanEnum} from "./payment-plan.model";
import {PaymentMethodEnum} from "./payment-method.model";

export interface IPolicyInitialization {
  isPolicyFinanced: boolean;
  financeCompanyId: string;
  typeOfBusiness: BusinessTypeEnum;
  activeCICPolicy: string;
  paymentType: PaymentTypeEnum;
  paymentPlan: PaymentPlanEnum;
  paymentAmount: number;
  paymentMethod: PaymentMethodEnum;
  memo: string;
  isPaymentByCheckConfirmed: boolean;
}
