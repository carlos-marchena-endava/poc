export enum BusinessTypeEnum {
  NEW_BUSINESS = "New Business",
  APPROVED_BOOK_TRANSFER = "Approved Book Transfer",
  REPLACING_ACTIVE_CIC_POLICY = "Replacing Active CIC Policy"
}
