export enum PaymentMethodEnum {
  NONE = "None",
  PAY_BY_CHECK = "Pay By Check"
}
