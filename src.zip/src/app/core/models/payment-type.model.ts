export enum PaymentTypeEnum {
  NONE = "None",
  PAY_BY_CHECK = "Pay By Check",
  PAID_AT_AGENCY = "Paid at Agency"
}
